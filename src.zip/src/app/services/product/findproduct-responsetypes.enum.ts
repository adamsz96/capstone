export enum FindProductResponseTypes {
    ProductFound = 1,
    ProductNotFound = 2,
    WaitForList = 3,
    ProductNameIsEmpty = 4,
    ErrorReadingProduct = 5
}
