export interface IUniqueStringIndex {
    uniqueName: string;
    uniqueNameOld: string;
}
