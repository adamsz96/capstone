import { TestBed } from '@angular/core/testing';
import { RestUniqueStringGenericService } from './rest-uniquestring-generic.service';

describe('RestgenericService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

});
