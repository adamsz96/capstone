import { MenuSubcategory } from './menucategory';

export class MenuItem {
    name: string;
    subcategories: MenuSubcategory[];
    showSubcategories: boolean;
}
