export enum CartGridRowEventTypes {
    quantityChanged = 1,
    rowRemoved = 2
}