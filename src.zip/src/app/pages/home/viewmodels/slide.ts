import { SlideImage } from './slideimage';

export class Slide {
    products: SlideImage[] = <SlideImage[]>[];
}
